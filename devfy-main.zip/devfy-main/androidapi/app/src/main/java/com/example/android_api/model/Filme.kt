package com.example.android_api.model

data class Filme(
    val id: String,
    val title: String,
    val productionCost: String,
    val imgUrl: String
)
