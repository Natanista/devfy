package com.example.android_api.model

data class UserCadastroEmpresa(
    val representante: String,
    val usuario: String,
    val senha: String,
    val nome: String,
    val cnpj: String
)
