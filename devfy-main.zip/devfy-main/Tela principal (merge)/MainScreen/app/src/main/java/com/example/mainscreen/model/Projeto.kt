package com.example.android_api.model

data class Projeto(
    val id: String,
    val titulo: String,
    val linguagem: String,
    val descricao: String,
    val categoria: String,
    val valor: String,
    val publicadoEm: String,
    val desenvolvedor: String,
    val empresa: String
)
