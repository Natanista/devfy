package com.example.android_api.model

data class UserLoginEmpresa(val usuario: String, val senha: String)
