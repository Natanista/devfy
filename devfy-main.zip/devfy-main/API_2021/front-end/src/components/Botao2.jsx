import React from "react";


function BotaoVerde() {
  return (
       <button type="submit" class="btn_green"> Logar </button>
  );
}

export default BotaoVerde;