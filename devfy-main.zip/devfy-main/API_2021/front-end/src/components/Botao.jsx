import React from "react";

function BotaoLaranja() {
  return (
    <div>
       <button class="btn_orange"> Empresa </button>
    </div>
  );
}

export default BotaoLaranja;