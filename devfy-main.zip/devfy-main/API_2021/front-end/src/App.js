import './html/css/style.css'
import './html/css/login.css'
import './html/css/menu.css'
import React from 'react'
import Rotas from './rotas';

function App() {
  return (
      <div>
        <Rotas/>
      </div>
  );
}

export default App;
