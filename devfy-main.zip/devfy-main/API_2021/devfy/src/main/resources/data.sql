INSERT INTO tbl_conta_bancaria
VALUES  (null, 1, 100.0);

INSERT INTO TBL_PROJETO ( ID_PROJETO , PROJ_CATEGORIA , PROJ_DESCRICAO , PROJ_LINGUAGEM , PROJ_TITULO , PROJ_VALOR ) VALUES (NULL , 'Web App', 'Divulgador de portifolio', 'Javascript', 'Site institucional', 300.0);
INSERT INTO TBL_PROJETO ( ID_PROJETO , PROJ_CATEGORIA , PROJ_DESCRICAO , PROJ_LINGUAGEM , PROJ_TITULO , PROJ_VALOR ) VALUES (NULL , 'Desktop App', 'Controlador de caixas de supermercado', 'Java', 'Software para caixas ', 1000.0);
INSERT INTO TBL_EMPRESA ( EMP_ID, EMP_NOME, EMP_EMAIL, EMP_TELEFONE, EMP_PAIS, EMP_CEP, EMP_REPRESENTANTE, EMP_TEL_REPRESENTANTE, EMP_USUARIO, EMP_SENHA, EMP_CNPJ ) VALUES (NULL, 'bandtec digital school', 'admin@sptech.com.br', '11983434555','BRASIL', '12345-123', 'Alessandro', '11912341234', 'administrador', 'admin12345', '46.562.748/0001-89');