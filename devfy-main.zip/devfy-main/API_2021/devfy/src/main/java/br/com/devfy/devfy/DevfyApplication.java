package br.com.devfy.devfy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevfyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevfyApplication.class, args);
	}

}
