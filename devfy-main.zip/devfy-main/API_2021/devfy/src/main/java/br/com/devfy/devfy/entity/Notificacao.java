package br.com.devfy.devfy.entity;


public interface Notificacao {

    public void notificarEmpresa();

    public void notificarCliente();

}
