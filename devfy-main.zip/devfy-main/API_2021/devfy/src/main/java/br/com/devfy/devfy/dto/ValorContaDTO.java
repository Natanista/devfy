package br.com.devfy.devfy.dto;

public class ValorContaDTO {

    private Double valor;



    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}
