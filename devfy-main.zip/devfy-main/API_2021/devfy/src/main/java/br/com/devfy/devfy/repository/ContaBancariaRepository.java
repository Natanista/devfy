package br.com.devfy.devfy.repository;

import br.com.devfy.devfy.entity.ContaBancaria;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ContaBancariaRepository extends JpaRepository<ContaBancaria, Integer> {

}
