package br.com.devfy.devfy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevfyApplicationTests {

	@Test
	void contextLoads() {
	}

}
